import { render, screen } from "@testing-library/react";
import App from "./App";

// test("check Sign out button", () => {
//   render(<App />);
//   const linkElement = screen.getByText("Sign out");
//   expect(linkElement).toBeInTheDocument();
// });

// test("check submit button", () => {
//   render(<App />);
//   const linkElement = screen.getByText("Submit");
//   expect(linkElement).toBeInTheDocument();
// });
